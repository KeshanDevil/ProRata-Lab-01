///////it21047756 weerasekara.w.b.m.k.d\\\\\\\\\\\\\\
public class Lab1Q1 {
    public static void main(String[] args) {
        System.out.println("Hello World! - IT21 047 756");
        
    }
}